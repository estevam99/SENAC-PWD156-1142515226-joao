import {Link} from 'react-router-dom'
import './style.css'
function Header(){
    return(
        <header>
                Bacana
                <div>
                        <Link to="/">HOME</Link>
                        <Link to="/cadastro"> CADASTRO</Link>
                        <Link to="/financiamento">financiamento</Link>
                        <Link to="/contas">contas</Link>
                        <Link to="sobre-nos">sobre nos</Link>
                </div>
        </header>)
}
export default Header