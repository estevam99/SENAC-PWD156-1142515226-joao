import './index.css'
function Home(){
    return(
        <body>
        <p class="phome">Página Home!<br/>
        </p>

        <div class="cont">
            
                <div class="botao">
                Você ainda não se cadastrou!<br/>
                Vá para a Página de cadastro<br/> 
                <a href="http://localhost:3000/cadastro"><br/>
                <button>Cadastrar</button>
                </a> 
                </div>

        </div>
        </body>
        
    )
}
export default Home