
function Sobre(){
    return(
        <body>
            <h1>Sobre nós!</h1>
            <div class="about">
                <p>
                Albert Einstein (Ulm, 14 de março de 1879 — Princeton, 18 de abril de 1955) foi um físico teórico alemão que desenvolveu a teoria da relatividade geral, um dos pilares da física moderna ao lado da mecânica quântica. Embora mais conhecido por sua fórmula de equivalência massa-energia, E = mc² — que foi chamada de "a equação mais famosa do mundo" —, foi laureado com o Prêmio Nobel de Física de 1921 "por suas contribuições à física teórica" e, especialmente, por sua descoberta da lei do efeito fotoelétrico, que foi fundamental no estabelecimento da teoria quântica.

Nascido em uma família de judeus alemães, mudou-se para a Suíça ainda jovem e iniciou seus estudos na Escola Politécnica de Zurique. Após dois anos procurando emprego, obteve um cargo no escritório de patentes suíço enquanto ingressava no curso de doutorado da Universidade de Zurique. Em 1905, publicou uma série de artigos acadêmicos revolucionários. Uma de suas obras era o desenvolvimento da teoria da relatividade especial. Percebeu, no entanto, que o princípio da relatividade também poderia ser estendido para campos gravitacionais, e com a sua posterior teoria da gravitação, de 1916, publicou um artigo sobre a teoria da relatividade geral. Enquanto acumulava cargos em universidades e instituições, continuou a lidar com problemas da mecânica estatística e teoria quântica, o que levou às suas explicações sobre a teoria das partículas e o movimento browniano. Também investigou as propriedades térmicas da luz, o que lançou as bases da teoria dos fótons. Em 1917, aplicou a teoria da relatividade geral para modelar a estrutura do universo como um todo. Suas obras renderam-lhe o status de celebridade mundial enquanto tornava-se uma nova figura na história da humanidade, recebendo prêmios internacionais e sendo convidado de chefes de estado e autoridades.

Estava nos Estados Unidos quando o Partido Nazista chegou ao poder na Alemanha, em 1933, e não voltou para o seu país de origem, onde tinha sido professor da Academia de Ciências de Berlim. Estabeleceu-se então no país, onde naturalizou-se em 1940. Na véspera da Segunda Guerra Mundial, ajudou a alertar o presidente Franklin Delano Roosevelt que a Alemanha poderia estar desenvolvendo uma arma atômica, recomendando aos norte-americanos a começar uma pesquisa semelhante, o que levou ao que se tornaria o Projeto Manhattan. Apoiou as forças aliadas, denunciando no entanto a utilização da fissão nuclear como uma arma. Mais tarde, com o filósofo britânico Bertrand Russell, assinou o Manifesto Russell-Einstein, que destacou o perigo das armas nucleares. Foi afiliado ao Instituto de Estudos Avançados de Princeton, onde trabalhou até sua morte em 1955.

Realizou diversas viagens ao redor do mundo, deu palestras públicas em conceituadas universidades e conheceu personalidades célebres de sua época, tanto na ciência quanto fora do mundo acadêmico. Publicou mais de 300 trabalhos científicos, juntamente com mais de 150 obras não científicas. Suas grandes conquistas intelectuais e originalidade fizeram da palavra "Einstein" sinônimo de gênio. Em 1999, foi eleito por 100 físicos renomados o mais memorável físico de todos os tempos. No mesmo ano, a revista TIME, em uma compilação com as pessoas mais importantes e influentes, classificou-o a pessoa do século XX.
                </p>
            </div>
                <a href="http://localhost:3000/"><br/>
                <button>Home</button>
                </a> 
        </body>
    )
}
export default Sobre