import './styleconta.css'

function Contas(){
    return(
        <body>
            <h1 class="helo">Contas registradas!</h1>
            <div class="pessoas">
                <div class="usu">
                    <img src="ze.jpg"/>
                    José dos Santos
                </div>

                <div class="usu">
                    <img src="eu.jpg" />
                    <strong>Eu</strong>
                </div>
                <a href="http://localhost:3000/financiamento"><br/>
                <button>Financiamento!</button>
                </a> 
            </div>
        </body>
    )
}
export default Contas