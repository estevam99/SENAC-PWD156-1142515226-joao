import './index.css'
function Cadastro(){
    return(
        <body>
            <p class="bemvindo"> Olá! Seja bem vindo!</p>
            <div class="conteudo">
            <div class="cad">
                <p class="cadastre"><strong>Cadastre-se imediatamente!</strong></p>
                <div class="div"></div>
                Seu nome: <input type="text" id="nomeUs"/><br/>
                <div class="div"></div>
                Seu CPF: <input type="text" id="CPF"/><br/>
                <div class="div"></div>
                Número do cartão: <input type="number"maxlength="9999999999999999" minlength="0"/><br/>
                <div class="div"></div>
                Os três números atrás: <input type="number"maxlength="999" minlength="100"/><br/>
                <div class="div"></div>
                <a href="http://localhost:3000/contas"><br/>
                <button>Cadastrar</button>
                </a> 
            </div>
            </div>
        </body>
    )
}

function clicar(){
    var nome = document.getElementById("nome")
}
export default Cadastro