import "./financindex.css"
function Financiamento(){
    return(
        <body>
            <div class="Financiamento">
                Quanto ira investir: <input type="number"/><br/>
                Seu salario: <input type="number"/>
            </div>
            <a href="http://localhost:3000/sobre-nos"><br/>
                <button>Sobre</button>
                </a> 
        </body>
    )
}
export default Financiamento