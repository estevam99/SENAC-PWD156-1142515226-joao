function Erro(){
    return(
    <div>
        <h1>Pagina não encontrada 
            erro 404</h1>
    </div>
    )

}
export default Erro